import { test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { openDb } from '../src/db.js';
import { createApp, limpiarTexto } from '../src/app.js';
import { formatear } from '../src/format.js';
import { crearModerador } from '../src/moderation.js';

// Google falso: el "code" con el que vuelve el login es el nombre de la persona.
const googleFalso = {
  urlAutorizacion: ({ state }) => `https://google.test/auth?state=${state}`,
  canjearCodigo: async ({ code }) => ({ sub: `sub-${code}`, email: `${code}@gmail.com` }),
};

async function montar({ google = googleFalso, sombra = null, production = false, alcanceKey = null, ultimaNota421 } = {}) {
  const db = openDb(':memory:');
  const reloj = { t: 1_800_000_000_000 };
  const filtro = { decision: 'approve' };
  const moderar = async () => ({
    decision: filtro.decision,
    rule: filtro.decision === 'reject' ? 'respeto' : 'ninguna',
    reason: filtro.decision === 'reject' ? 'Tu mensaje ataca a otra persona.' : '',
    model: 'falso',
    input_tokens: 1,
    output_tokens: 1,
    grave: filtro.grave ?? 'ninguna',
  });
  const app = createApp({
    db,
    moderar,
    google,
    loginDePrueba: !google,
    secret: 'secreto-de-prueba',
    baseUrl: 'http://prueba',
    siteName: 'prueba',
    adminEmails: ['mod@gmail.com'],
    now: () => reloj.t,
    sombra,
    geminiUrl: 'gemini://prueba',
    production,
    alcanceKey,
    ultimaNota421,
  });
  const server = app.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = `http://127.0.0.1:${server.address().port}`;

  const pedir = (ruta, { sesion, datos, cookie } = {}) =>
    fetch(base + ruta, {
      method: datos ? 'POST' : 'GET',
      headers: sesion || cookie ? { cookie: sesion?.cookie ?? cookie } : {},
      body: datos ? new URLSearchParams({ ...(sesion ? { _csrf: sesion.csrf } : {}), ...datos }) : undefined,
      redirect: 'manual',
    });
  const texto = async (ruta, sesion) => (await pedir(ruta, { sesion })).text();

  async function leerSesion(respuesta) {
    const cookie = respuesta.headers
      .getSetCookie()
      .find((c) => c.startsWith('sid='))
      .split(';')[0];
    const home = await (await pedir('/', { cookie })).text();
    return { cookie, csrf: home.match(/name="_csrf" value="([^"]+)"/)[1] };
  }

  async function inicioGoogle() {
    const r = await pedir('/auth/google');
    assert.equal(r.status, 302);
    return {
      oauth: r.headers.getSetCookie()[0].split(';')[0],
      state: new URL(r.headers.get('location')).searchParams.get('state'),
    };
  }

  async function entrar(nombre) {
    const { oauth, state } = await inicioGoogle();
    const r = await pedir(`/auth/google/callback?code=${nombre}&state=${state}`, { cookie: oauth });
    assert.equal(r.status, 303);
    return leerSesion(r);
  }

  return {
    db,
    filtro,
    pedir,
    texto,
    entrar,
    inicioGoogle,
    leerSesion,
    avanzar: (seg) => (reloj.t += seg * 1000),
    base,
    documento: app.locals.documento,
    gemini: app.locals.gemini,
    cerrar: () => server.close(),
  };
}

test('formatear escapa todo y agrega solo las marcas propias', () => {
  const h = formatear('<script>alert(1)</script>\n>cita\n>>5 y >>9\n[spoiler]final[/spoiler]', {
    idsLocales: new Set([5]),
  });
  assert.ok(!h.includes('<script>'));
  assert.ok(h.includes('&lt;script&gt;'));
  assert.ok(h.includes('<span class="verde">&gt;cita</span>'));
  assert.ok(h.includes('<a class="cita" href="#p5">&gt;&gt;5</a>'));
  assert.ok(h.includes('<a class="cita" href="/p/9">&gt;&gt;9</a>'));
  assert.ok(!h.includes('<span class="verde"><a'), 'una línea que empieza con >>N no es cita verde');
  assert.ok(h.includes('<span class="spoiler" tabindex="0">final</span>'));
});

test('limpiarTexto saca caracteres invisibles y conserva espacios y signos', () => {
  const anchoCero = String.fromCharCode(0x200b);
  const invertir = String.fromCharCode(0x202e);
  const entrada = `hola${anchoCero} mundo${invertir}, ¿qué tal?\n\n\n\nchau  `;
  assert.equal(limpiarTexto(entrada), 'hola mundo, ¿qué tal?\n\nchau');
});

test('entrar con Google guarda solo el identificador, nunca el correo', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  await s.entrar('ana');
  assert.deepEqual(s.db.prepare('SELECT identidad FROM users').all(), [{ identidad: 'google:sub-ana' }]);
  const columnas = s.db.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
  assert.ok(!columnas.includes('email'));
});

test('una cuenta que sale de la lista de admins deja de ser admin al volver a entrar', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  await s.entrar('ana');
  s.db.prepare("UPDATE users SET role = 'admin' WHERE identidad = 'google:sub-ana'").run();
  const ana = await s.entrar('ana');
  assert.equal(s.db.prepare("SELECT role FROM users WHERE identidad = 'google:sub-ana'").get().role, 'user');
  assert.notEqual((await s.pedir('/mod', { sesion: ana })).status, 200);
});

test('el login con Google rechaza un state que no coincide', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const { oauth } = await s.inicioGoogle();
  assert.equal((await s.pedir('/auth/google/callback?code=ana&state=otro', { cookie: oauth })).status, 400);
  assert.equal((await s.pedir('/auth/google/callback?code=ana&state=otro')).status, 400);
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM users').get().n, 0);
});

test('el acceso de prueba solo existe cuando no hay Google', async (t) => {
  const conGoogle = await montar();
  t.after(conGoogle.cerrar);
  assert.equal((await conGoogle.pedir('/entrar/prueba', { datos: { nombre: 'x' } })).status, 404);

  const sinGoogle = await montar({ google: null });
  t.after(sinGoogle.cerrar);
  assert.equal((await sinGoogle.pedir('/auth/google')).status, 404);
  const r = await sinGoogle.pedir('/entrar/prueba', { datos: { nombre: 'Juan', admin: '1' } });
  assert.equal(r.status, 303);
  const juan = await sinGoogle.leerSesion(r);
  assert.equal((await sinGoogle.pedir('/mod', { sesion: juan })).status, 200);
});

test('publicar un hilo aprobado y verlo sin HTML inyectado', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');

  const r = await s.pedir('/b/cultura/hilo', {
    sesion: ana,
    datos: { asunto: 'Libros <b>raros</b>', cuerpo: 'Recomienden <script>alert(1)</script>' },
  });
  assert.equal(r.status, 303);
  assert.equal(r.headers.get('location'), '/h/1');

  const respuesta = await s.pedir('/h/1');
  assert.match(respuesta.headers.get('content-security-policy'), /default-src 'self'; script-src 'self';/);
  const hilo = await respuesta.text();
  assert.ok(hilo.includes('Libros &lt;b&gt;raros&lt;/b&gt;'));
  assert.ok(!hilo.includes('<script>alert'));
  assert.ok(hilo.includes('Pseudoanónimo'));
  assert.ok((await s.texto('/b/cultura')).includes('/h/1'));
  assert.ok((await s.texto('/')).includes('/h/1'), 'la portada muestra los hilos');
});

test('abrir un hilo desde la portada exige elegir tablón', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');

  const sinTablon = await s.pedir('/hilo', { sesion: ana, datos: { asunto: 'Sin tablón', cuerpo: 'hola' } });
  assert.equal(sinTablon.status, 422);
  assert.ok((await sinTablon.text()).includes('Elegí en qué tablón'));

  const r = await s.pedir('/hilo', { sesion: ana, datos: { tablon: 'juegos', asunto: 'Con tablón', cuerpo: 'hola' } });
  assert.equal(r.status, 303);
  assert.equal(s.db.prepare('SELECT board FROM threads WHERE id = 1').get().board, 'juegos');
});

test('el listado muestra las últimas respuestas y cuántas se omitieron', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Largo', cuerpo: 'inicio' } });
  for (const cuerpo of ['r-uno', 'r-dos', 'r-tres', 'r-cuatro', 'r-cinco']) {
    s.avanzar(31);
    await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo } });
  }

  const portada = await s.texto('/?vista=lista');
  assert.ok(portada.includes('2 respuestas omitidas'));
  for (const visible of ['inicio', 'r-tres', 'r-cuatro', 'r-cinco']) assert.ok(portada.includes(visible), visible);
  for (const oculta of ['r-uno', 'r-dos']) assert.ok(!portada.includes(oculta), oculta);
  assert.ok((await s.texto('/h/1')).includes('r-uno'), 'el hilo completo tiene todo');
});

test('el catálogo es la vista por defecto, tapa spoilers y solo enlaza el asunto', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', {
    sesion: ana,
    datos: { asunto: 'Final de la serie', cuerpo: '>>99 decía que [spoiler]muere el protagonista[/spoiler] y era mentira' },
  });

  const portada = await s.texto('/');
  assert.ok(portada.includes('class="catalogo"'));
  assert.ok(portada.includes('R: 0'));
  assert.ok(!portada.includes('muere el protagonista'), 'el spoiler no aparece en la ficha');
  const ficha = portada.slice(portada.indexOf('class="ficha"'), portada.indexOf('</article>', portada.indexOf('class="ficha"')));
  assert.equal((ficha.match(/<a /g) || []).length, 1, 'solo el asunto es link');
  assert.ok(ficha.includes('<a class="ficha-asunto" href="/h/1"><strong>Final de la serie</strong></a>'));
  assert.ok((await s.texto('/b/cultura')).includes('class="catalogo"'));
});

test('un POST sin token CSRF válido se rechaza', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const r = await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { _csrf: 'falso', asunto: 'a', cuerpo: 'b' } });
  assert.equal(r.status, 403);
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM posts').get().n, 0);
});

test('un rechazo no publica, no explica el motivo y devuelve el texto', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  s.filtro.decision = 'reject';

  const r = await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Asunto rechazado', cuerpo: 'texto original' } });
  assert.equal(r.status, 422);
  const pagina = await r.text();
  assert.ok(pagina.includes('No se publicó: el mensaje no cumple las normas.'));
  assert.ok(!pagina.includes('Tu mensaje ataca a otra persona.'));
  assert.ok(pagina.includes('>texto original</textarea>'));
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM threads').get().n, 0);
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM rechazos').get().n, 1);
});

test('en revisión solo lo ve el autor hasta que un mod lo aprueba', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  s.filtro.decision = 'queue';

  const r = await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Dudoso', cuerpo: 'algo ambiguo' } });
  assert.equal(r.headers.get('location'), '/h/1?aviso=cola');
  assert.equal((await s.pedir('/h/1')).status, 404);
  assert.ok((await s.texto('/h/1', ana)).includes('En revisión'));

  const mod = await s.entrar('mod');
  const panel = await s.texto('/mod', mod);
  assert.ok(panel.includes('Dudoso'));
  assert.ok(panel.includes('href="/h/1#p1"'), 'el enlace de la cola abre el mensaje dentro de su publicación');
  assert.equal((await s.pedir('/mod', { sesion: ana })).status, 404, 'un usuario común no ve /mod');
  assert.equal((await s.pedir('/mod/p/1/aprobar', { sesion: ana, datos: {} })).status, 404, 'ni puede moderar');

  assert.equal((await s.pedir('/mod/p/1/aprobar', { sesion: mod, datos: {} })).status, 303);
  const publico = await s.pedir('/h/1');
  assert.equal(publico.status, 200);
  assert.ok(!(await publico.text()).includes('En revisión'));
});

test('límite de frecuencia, y sage responde sin subir el hilo', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  const orden = async () => {
    const h = await s.texto('/b/cultura');
    return h.indexOf('/h/1') < h.indexOf('/h/2') ? [1, 2] : [2, 1];
  };

  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Hilo uno', cuerpo: 'primero' } });
  s.avanzar(601);
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Hilo dos', cuerpo: 'segundo' } });
  assert.deepEqual(await orden(), [2, 1]);

  s.avanzar(1);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'respuesta con sage', sage: '1' } });
  assert.deepEqual(await orden(), [2, 1], 'sage no sube el hilo');

  const apurada = await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'otra enseguida' } });
  assert.equal(apurada.status, 429);
  assert.ok((await apurada.text()).includes('Esperá'));

  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'respuesta normal' } });
  assert.deepEqual(await orden(), [1, 2], 'una respuesta normal sí lo sube');
});

test('tres reportes ocultan el post hasta que lo revise un mod', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'respuesta-a-ocultar' } });

  const reportantes = [];
  for (const nombre of ['c1', 'c2', 'c3']) reportantes.push(await s.entrar(nombre));
  // Cuentas recién creadas: reportan, pero no alcanzan para ocultar.
  for (const u of reportantes) await s.pedir('/p/2/reportar', { sesion: u, datos: { motivo: 'respeto' } });
  assert.ok((await s.texto('/h/1')).includes('respuesta-a-ocultar'));
  // Con más de un día, los mismos reportes sí ocultan.
  s.avanzar(86_401);
  const c4 = await s.entrar('c4');
  s.db.prepare("UPDATE reports SET created_at = created_at").run();
  await s.pedir('/p/2/reportar', { sesion: c4, datos: { motivo: 'respeto' } });
  assert.ok(!(await s.texto('/h/1')).includes('respuesta-a-ocultar'));
  const mod = await s.entrar('mod');
  assert.ok((await s.texto('/mod', mod)).includes('respuesta-a-ocultar'));
});

test('uno o dos reportes no alcanzan para ocultar un post', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'sigue-visible' } });
  const reportantes = [await s.entrar('c1'), await s.entrar('c2')];
  s.avanzar(86_401);
  for (const u of reportantes) {
    await s.pedir('/p/1/reportar', { sesion: u, datos: { motivo: 'respeto' } });
    assert.ok((await s.texto('/h/1')).includes('sigue-visible'));
  }
});

test('reportar: cada mensaje lleva un link y el formulario está en su propia página', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'una respuesta' } });

  // En la publicación, un link por mensaje y ningún formulario de reporte.
  const hilo = await s.texto('/h/1', ana);
  assert.ok(hilo.includes('<a class="reportar" href="/p/2/reportar" rel="nofollow">Reportar</a>'));
  assert.ok(!hilo.includes('name="motivo"') && !hilo.includes('<details class="reportar"'));

  const pagina = await s.texto('/p/2/reportar', ana);
  assert.ok(pagina.includes('action="/p/2/reportar"') && pagina.includes('<option value="respeto">'));
  assert.ok(pagina.includes('una respuesta') && pagina.includes('href="/h/1#p2"') && pagina.includes('noindex'));

  assert.equal((await s.pedir('/p/2/reportar')).headers.get('location'), '/entrar');
  assert.equal((await s.pedir('/p/2/reportar', { sesion: bea })).headers.get('location'), '/h/1#p2', 'el propio mensaje no se reporta');
  assert.equal((await s.pedir('/p/99/reportar', { sesion: ana })).status, 404);

  // El envío sigue igual: vuelve al mensaje con el aviso.
  const r = await s.pedir('/p/2/reportar', { sesion: ana, datos: { motivo: 'spam' } });
  assert.equal(r.headers.get('location'), '/h/1?aviso=reportado#p2');
});

test('filtro: si no responde, el mensaje va a revisión; un caso de tolerancia cero se rechaza aunque el filtro diga aprobar', async (t) => {
  t.mock.method(console, 'error', () => {});
  const moderar = (parse) => crearModerador({ siteName: 'prueba', client: { messages: { parse } } });
  const datos = { tablon: 'Cultura', asunto: 'a', cuerpo: 'b', esHilo: true };
  const caido = moderar(async () => { throw new Error('API caída'); });
  assert.equal((await caido(datos)).decision, 'queue', 'sin respuesta del filtro no se publica');
  const contradictorio = moderar(async () => ({ usage: {}, parsed_output: { decision: 'approve', grave: 'menores' } }));
  assert.equal((await contradictorio(datos)).decision, 'reject', 'tolerancia cero gana sobre aprobar');
});

test('la página de privacidad existe y no promete guardar el correo', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const texto = await s.texto('/privacidad');
  assert.ok(texto.includes('Ley Nº 25.326'));
  assert.ok(texto.includes('no lo guardamos'));
  assert.ok((await s.texto('/entrar')).includes('href="/privacidad"'));
});

test('borrar la cuenta vacía los mensajes y deja las respuestas ajenas', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Asunto-de-ana', cuerpo: 'texto-de-ana' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'respuesta-de-bea' } });

  const r = await s.pedir('/cuenta/borrar', { sesion: ana, datos: { confirmar: '1' } });
  assert.equal(r.status, 303);
  const hilo = await s.texto('/h/1');
  assert.ok(!hilo.includes('texto-de-ana') && !hilo.includes('Asunto-de-ana'));
  assert.ok(hilo.includes('respuesta-de-bea'));
  assert.ok(hilo.includes('Eliminado por su autor'));
  assert.equal(s.db.prepare("SELECT COUNT(*) AS n FROM users WHERE identidad LIKE '%ana%'").get().n, 0);
  assert.equal(s.db.prepare("SELECT COUNT(*) AS n FROM users WHERE identidad LIKE 'borrada:%'").get().n, 1);
  // La sesión vieja ya no sirve.
  assert.equal((await s.pedir('/cuenta', { sesion: ana })).status, 303);
});

test('una publicación sin respuestas se oculta al borrar la cuenta', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Sola', cuerpo: 'sin-respuestas' } });
  await s.pedir('/cuenta/borrar', { sesion: ana, datos: { confirmar: '1' } });
  assert.ok(!(await s.texto('/')).includes('Sola'));
});

test('borrar la cuenta exige confirmar', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const r = await s.pedir('/cuenta/borrar', { sesion: ana, datos: {} });
  assert.equal(r.status, 422);
});

test('la página de términos existe', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  assert.ok((await s.texto('/terminos')).includes('Términos de uso'));
});

test('SEO: metas, canonical, noindex donde corresponde, sitemap y datos de foro', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Libros </script> raros', cuerpo: 'Recomienden ciencia ficción argentina' } });

  const portada = await s.texto('/');
  assert.ok(portada.includes('<meta name="description"'));
  assert.ok(portada.includes('rel="canonical" href="http://localhost/"') || portada.includes('rel="canonical"'));
  assert.ok(!portada.includes('noindex'));
  assert.ok((await s.texto('/?vista=lista')).includes('noindex'));
  assert.ok((await s.texto('/entrar')).includes('noindex'));

  const hilo = await s.texto('/h/1');
  assert.ok(hilo.includes('content="Recomienden ciencia ficción argentina"'));
  assert.ok(hilo.includes('"@type":"DiscussionForumPosting"'));
  // El asunto con </script> no puede cerrar el bloque JSON-LD.
  const ld = hilo.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1];
  assert.equal(JSON.parse(ld).headline, 'Libros </script> raros');

  const mapa = await s.texto('/sitemap.xml');
  assert.ok(mapa.includes('/h/1</loc>') && mapa.includes('/b/cultura</loc>'));
  assert.ok((await s.texto('/robots.txt')).includes('Sitemap:'));
});

test('citas: la publicación carga citas.js y los >>N siguen siendo links a #pN', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: '>>1\nte contesto' } });
  const hilo = await s.texto('/h/1');
  assert.match(hilo, /<script src="\/static\/citas\.js\?v=[0-9a-f]+" defer><\/script>/);
  // Sin JavaScript todo sigue funcionando: la cita y la respuesta entrante son links al mensaje.
  assert.ok(hilo.includes('<a class="cita" href="#p1">&gt;&gt;1</a>') && hilo.includes('<a href="#p2">&gt;&gt;2</a>'));
  assert.ok(!(await s.texto('/')).includes('citas.js'), 'solo en las publicaciones');
});

test('fechas: corta a la vista, completa al pasar el mouse y en datetime', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  // El reloj de prueba arranca en 1.800.000.000.000 ms: 15/1/2027 08:00 UTC, 5:00 en Buenos Aires.
  // Según la versión de ICU, "a. m." lleva un espacio duro (U+00A0 o U+202F): se normaliza.
  const hilo = (await s.texto('/h/1')).replace(/[\u00a0\u202f]/g, ' ');
  assert.ok(hilo.includes('<time datetime="2027-01-15T08:00:00.000Z" title="viernes, 15 de enero de 2027, 5:00 a. m.">15/1/27, 5:00 a. m.</time>'));
  assert.ok(!hilo.includes('<time>'), 'ninguna fecha sin datetime');
});

test('responder a un post: cita precargada, respuestas entrantes y marca propia', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'primera respuesta' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: '>>2\nte contesto a vos' } });

  const conCita = await s.texto('/h/1?cita=2', bea);
  assert.ok(conCita.includes('>&gt;&gt;2\n</textarea>') || conCita.includes('&gt;&gt;2\n</textarea>'));
  assert.ok(conCita.includes('href="?cita=2#responder"'));
  // El campo queda marcado: formularios.js suma el >>N al borrador que había en vez de pisarlo.
  assert.ok(conCita.includes(' data-cita="2">&gt;&gt;2\n</textarea>'));
  assert.ok(!(await s.texto('/h/1', bea)).includes('data-cita'));
  assert.ok(!(await s.texto('/h/1?cita=99', bea)).includes('data-cita'), 'un número que no es de la publicación no se cita');

  const hilo = await s.texto('/h/1', bea);
  assert.ok(hilo.includes('Respuestas: <a href="#p3">&gt;&gt;3</a>'));
  // bea ve "(vos)" solo en su mensaje; sin sesión no aparece.
  assert.equal(hilo.split('marca-vos').length - 1, 1);
  assert.ok(!(await s.texto('/h/1')).includes('marca-vos'));

  const participaste = await s.texto('/respuestas', ana);
  assert.ok(participaste.includes('href="/h/1">Tema</a>'));
});

test('la página de formato muestra cada código escrito y renderizado', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const p = await s.texto('/formato');
  assert.ok(p.includes('<span class="spoiler"'));
  assert.ok(p.includes('<a class="cita" href="#p34">'));
  assert.ok(p.includes('<span class="verde">'));
  assert.ok((await s.texto('/sitemap.xml')).includes('/formato</loc>'));
});

test('notificaciones: comentario al OP, respuesta por cita, nunca a uno mismo, se marcan leídas', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: 'me comento a mí misma' } });
  assert.ok(!(await s.texto('/', ana)).includes('class="badge"'));

  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'comentario de bea' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: '>>3\nte cito, bea' } });

  assert.ok((await s.texto('/', ana)).includes('<span class="badge">1</span>'));
  assert.ok((await s.texto('/', bea)).includes('<span class="badge">1</span>'));
  const pagina = await s.texto('/respuestas', bea);
  assert.ok(pagina.includes('te respondió') && pagina.includes('te cito, bea'));
  assert.ok(!(await s.texto('/', bea)).includes('class="badge"'));
});

test('actualización en vivo: /h/:id/nuevos trae solo lo posterior y respeta la visibilidad', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  const pagina = await s.texto('/h/1');
  assert.ok(pagina.includes('data-hilo="1" data-ultimo="1"') && pagina.includes('/static/vivo.js?v='));

  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'algo nuevo' } });
  const r = JSON.parse(await s.texto('/h/1/nuevos?desde=1'));
  assert.equal(r.ultimo, 2);
  assert.ok(r.html.includes('algo nuevo') && !r.html.includes('arranque'));
  assert.equal(JSON.parse(await s.texto('/h/1/nuevos?desde=2')).html.trim(), '');
  assert.equal((await s.pedir('/h/99/nuevos?desde=0')).status, 404);
});

test('estáticos: con hash se guardan un año sin volver a preguntar; sin hash, un día', async (t) => {
  const s = await montar({ production: true });
  t.after(s.cerrar);
  const css = (await s.texto('/normas')).match(/\/static\/style\.css\?v=[0-9a-f]+/)[0];
  const cache = async (ruta) => (await s.pedir(ruta)).headers.get('cache-control');
  assert.equal(await cache(css), 'public, max-age=31536000, immutable');
  assert.equal(await cache('/static/favicon.svg'), 'public, max-age=86400');
  const noExiste = await s.pedir('/static/no-existe.css?v=abc');
  assert.equal(noExiste.status, 404);
  assert.ok(!(noExiste.headers.get('cache-control') ?? '').includes('immutable'), 'un 404 no se guarda un año');
  const dev = await montar();
  t.after(dev.cerrar);
  assert.equal((await dev.pedir(css)).headers.get('cache-control'), 'public, max-age=0');
});

test('tema claro/oscuro por cookie, sin JavaScript', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const auto = await s.texto('/normas');
  assert.ok(auto.includes('<html lang="es">') && auto.includes('prefers-color-scheme: light'));
  assert.ok(auto.includes('class="boton-tema"') && !auto.includes('Usar el tema del sistema'));

  const r = await s.pedir('/tema?t=claro&volver=%2Fnormas');
  assert.equal(r.status, 303);
  assert.equal(r.headers.get('location'), '/normas');
  const cookie = r.headers.getSetCookie()[0].split(';')[0];
  const claro = await (await s.pedir('/normas', { cookie })).text();
  assert.ok(claro.includes('data-tema="claro"'));

  assert.equal((await s.pedir('/tema?t=oscuro&volver=//evil.com')).headers.get('location'), '/');
});

test('temas descanso y monocromo desde Mi cuenta', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const cuenta = await s.texto('/cuenta', ana);
  assert.ok(cuenta.includes('href="/tema?t=descanso&amp;volver=%2Fcuenta"') && cuenta.includes('href="/tema?t=monocromo&amp;volver=%2Fcuenta"'));
  for (const [tema, fondo] of [['descanso', '#191a1d'], ['monocromo', '#161616']]) {
    const cookie = (await s.pedir(`/tema?t=${tema}&volver=%2Fcuenta`)).headers.getSetCookie()[0].split(';')[0];
    const pagina = await (await s.pedir('/normas', { cookie })).text();
    assert.ok(pagina.includes(`data-tema="${tema}"`) && pagina.includes(`content="${fondo}"`));
  }
});

test('tema: el script que lo cambia sin recargar va en todas las páginas y el botón sigue siendo un link', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const pagina = await s.texto('/normas');
  const src = pagina.match(/<script src="(\/static\/tema\.js\?v=[0-9a-f]+)" data-colores="([^"]+)" defer><\/script>/)?.[1];
  assert.ok(src, 'falta tema.js en la página');
  // El script conoce todos los temas (si no, elegir uno nuevo borraba la cookie).
  const colores = JSON.parse(pagina.match(/data-colores="([^"]+)"/)[1].replace(/&quot;/g, '"'));
  assert.deepEqual(Object.keys(colores).sort(), ['claro', 'descanso', 'monocromo', 'oscuro']);
  const ana = await s.entrar('ana');
  const cuenta = await s.texto('/cuenta', ana);
  assert.ok(/href="\/tema\?t=auto[^"]*"[^>]*aria-current="true"/.test(cuenta), 'sin cookie, "sistema" es la opción marcada');
  assert.ok(pagina.includes('class="icono a-claro" href="/tema?t=claro&amp;volver='));
  const js = await s.pedir(src);
  assert.equal(js.status, 200);
  assert.ok((await js.text()).includes("a[href^=\"/tema?\"]"));
});

test('vista lista o catálogo por cookie, y el parámetro le gana', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Largo', cuerpo: 'inicio' } });

  const sinCookie = await s.texto('/');
  assert.ok(sinCookie.includes('class="catalogo"'), 'sin cookie manda el catálogo');
  assert.ok(sinCookie.includes('href="/vista?v=lista&amp;volver=%2F"'), 'el selector lleva a /vista');

  const puesta = (r) => r.headers.getSetCookie().find((c) => c.startsWith('vista='));
  const r = await s.pedir('/vista?v=lista&volver=%2F');
  assert.equal(r.status, 303);
  assert.equal(r.headers.get('location'), '/');
  const cookie = puesta(r).split(';')[0];
  assert.equal(cookie, 'vista=lista');

  // La elección se mantiene sin ?vista= en la URL, también en un tablón.
  for (const [ruta, volver] of [['/', '%2F'], ['/b/cultura', '%2Fb%2Fcultura']]) {
    const pagina = await (await s.pedir(ruta, { cookie })).text();
    assert.ok(pagina.includes('class="hilo-resumen"'), `${ruta} en lista`);
    assert.ok(!pagina.includes('class="catalogo"'), `${ruta} sin catálogo`);
    assert.ok(pagina.includes(`href="/vista?v=catalogo&amp;volver=${volver}"`), `${ruta} vuelve a su propia ruta`);
  }

  // El parámetro gana, pero no guarda nada: un link compartido se ve como lo mandaron y la
  // preferencia de quien lo abre queda como estaba.
  assert.ok((await (await s.pedir('/?vista=catalogo', { cookie })).text()).includes('class="catalogo"'));
  assert.ok((await (await s.pedir('/', { cookie })).text()).includes('class="hilo-resumen"'), 'el parámetro no pisó la cookie');

  // Volver al catálogo también se guarda: no es lo mismo que no haber elegido nunca.
  const vuelta = puesta(await s.pedir('/vista?v=catalogo&volver=%2F')).split(';')[0];
  assert.equal(vuelta, 'vista=catalogo');
  assert.ok((await (await s.pedir('/', { cookie: vuelta })).text()).includes('class="catalogo"'));

  // Un valor fuera de la lista borra la cookie, y el volver sigue siendo solo del propio sitio.
  assert.ok(puesta(await s.pedir('/vista?v=zzz&volver=%2F')).startsWith('vista=;'));
  for (const malo of ['//evil.com', '/\\evil.com', 'https://evil.com', '/\tevil']) {
    assert.equal((await s.pedir(`/vista?v=lista&volver=${encodeURIComponent(malo)}`)).headers.get('location'), '/', malo);
  }
});

test('vista: la cookie es httpOnly y la elección se ve en Mi cuenta', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  // A diferencia de `tema`, ningún script del cliente la toca.
  const puesta = (r) => r.headers.getSetCookie().find((c) => c.startsWith('vista='));
  assert.match(puesta(await s.pedir('/vista?v=lista&volver=%2F')), /httponly/i);

  const ana = await s.entrar('ana');
  const sinElegir = await s.texto('/cuenta', ana);
  assert.ok(/href="\/vista\?v=catalogo[^"]*"[^>]*aria-current="true"/.test(sinElegir), 'sin cookie, catálogo es lo marcado');
  assert.ok(sinElegir.includes('href="/vista?v=lista&amp;volver=%2Fcuenta"'));
  const conLista = await (await s.pedir('/cuenta', { cookie: `${ana.cookie}; vista=lista` })).text();
  assert.ok(/href="\/vista\?v=lista[^"]*"[^>]*aria-current="true"/.test(conLista), 'con cookie, lista es lo marcado');
});

test('tolerancia cero: un caso grave rechaza, suspende la cuenta y un mod la puede levantar', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  s.filtro.decision = 'reject';
  s.filtro.grave = 'menores';
  const r = await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'x', cuerpo: 'contenido prohibido' } });
  assert.equal(r.status, 422);
  const u = s.db.prepare("SELECT banned_until, ban_reason FROM users WHERE identidad LIKE '%ana%'").get();
  assert.ok(u.banned_until > 1_800_000_000_000 + 365 * 86_400_000 && u.ban_reason.includes('menores'));

  s.filtro.decision = 'approve';
  s.filtro.grave = 'ninguna';
  const bloqueada = await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'y', cuerpo: 'otro' } });
  assert.notEqual(bloqueada.status, 303);
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM threads').get().n, 0);

  const mod = await s.entrar('mod');
  const panel = await s.texto('/mod', mod);
  assert.ok(panel.includes('abuso infantil (permanente)') && panel.includes('contenido prohibido'));
  const id = s.db.prepare("SELECT id FROM users WHERE identidad LIKE '%ana%'").get().id;
  await s.pedir(`/mod/u/${id}/levantar`, { sesion: mod, datos: {} });
  assert.equal(s.db.prepare('SELECT banned_until FROM users WHERE id = ?').get(id).banned_until, null);
});

test('barra inferior y botón de tema', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const anon = await s.texto('/');
  assert.ok(anon.includes('class="abajo"') && anon.includes('href="/entrar"') && anon.includes('class="boton-tema"'));
  const ana = await s.entrar('ana');
  const conSesion = await s.texto('/b/cultura', ana);
  assert.ok(conSesion.includes('href="/b/cultura?publicar=1#publicar"') && conSesion.includes('>Respuestas</a>'));
  assert.ok((await s.texto('/?publicar=1', ana)).includes('id="publicar" open'));
});

test('versión texto: .txt, curl en la dirección normal, spoilers tapados y 404', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Libros', cuerpo: '>una cita\nhola [spoiler]final[/spoiler]' } });

  const r = await s.pedir('/h/1.txt');
  assert.match(r.headers.get('content-type'), /^text\/plain/);
  const txt = await r.text();
  assert.ok(txt.includes('Libros') && txt.includes('> una cita') && txt.includes('[spoiler: leelo en la web]'));
  assert.ok(!txt.includes('final') && !txt.includes('<'));

  const curl = await fetch(s.base + '/h/1', { headers: { 'user-agent': 'curl/8.5.0' } });
  assert.match(curl.headers.get('content-type'), /^text\/plain/);
  assert.ok((await (await fetch(s.base + '/', { headers: { 'user-agent': 'curl/8.5.0' } })).text()).includes('Últimas publicaciones'));
  assert.match((await s.pedir('/h/1')).headers.get('content-type'), /^text\/html/);

  assert.ok((await s.texto('/b/cultura.txt')).includes('Libros'));
  assert.ok((await s.texto('/normas.txt')).includes('Sin acoso'));
  assert.equal((await s.pedir('/h/99.txt')).status, 404);
  assert.ok((await s.texto('/h/1')).includes('rel="alternate" type="text/plain"'));
});

test('cápsula Gemini: portada, publicación, 51 y host ajeno', async (t) => {
  const { execFileSync } = await import('node:child_process');
  const fs = await import('node:fs');
  const os = await import('node:os');
  const path = await import('node:path');
  const tls = await import('node:tls');
  const { crearCapsula } = await import('../src/gemini.js');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gemini-'));
  execFileSync('openssl', ['req', '-x509', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:prime256v1', '-nodes', '-days', '1',
    '-subj', '/CN=localhost', '-keyout', path.join(dir, 'k.pem'), '-out', path.join(dir, 'c.pem')], { stdio: 'ignore' });

  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Libros', cuerpo: '>cita\nhola' } });

  const capsula = crearCapsula({ documento: s.documento, baseUrl: 'https://prueba', cert: fs.readFileSync(path.join(dir, 'c.pem')), key: fs.readFileSync(path.join(dir, 'k.pem')), hosts: ['localhost'] });
  await new Promise((r) => capsula.listen(0, '127.0.0.1', r));
  t.after(() => capsula.close());
  const port = capsula.address().port;
  const pedir = (url) => new Promise((resolve, reject) => {
    const c = tls.connect({ host: '127.0.0.1', port, servername: 'localhost', rejectUnauthorized: false }, () => c.write(`${url}\r\n`));
    let d = '';
    c.on('data', (x) => (d += x)).on('end', () => resolve(d)).on('error', reject);
  });

  const portada = await pedir('gemini://localhost/');
  assert.ok(portada.startsWith('20 text/gemini') && portada.includes('=> /h/1 [Cultura] Libros'));
  const hilo = await pedir('gemini://localhost/h/1');
  assert.ok(hilo.includes('## Libros') && hilo.includes('> cita') && hilo.includes('=> https://prueba/h/1 Responder en la web'));
  assert.ok((await pedir('gemini://localhost/h/99')).startsWith('51'));
  assert.ok((await pedir('gemini://otro.sitio/')).startsWith('53'));
  // Auditoría 2026-09-25: un % inválido tiraba abajo todo el proceso (web incluida).
  assert.ok((await pedir('gemini://localhost/%E0')).startsWith('59'));
  assert.ok((await pedir('gemini://localhost/%ZZ')).startsWith('59'));
  assert.ok((await pedir('gemini://localhost/')).startsWith('20'), 'la cápsula sigue viva');
});

test('nuevo desde la última visita: se mantiene al recargar y se renueva tras una hora sin entrar', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Viejo', cuerpo: 'hola' } });
  // Primera visita de un lector sin cuenta: no se marca nada.
  const galleta = async (cookie) => {
    const r = await s.pedir('/', { cookie });
    const nueva = r.headers.getSetCookie().find((c) => c.startsWith('visita='))?.split(';')[0];
    return { html: await r.text(), cookie: nueva ?? cookie };
  };
  let v = await galleta();
  assert.ok(!v.html.includes('marca-nuevo'));
  // Lo que se publica durante esa primera visita ya se marca.
  s.avanzar(40);
  await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: 'mientras navegás' } });
  v = await galleta(v.cookie);
  assert.ok(v.html.includes('1 nueva'));
  s.avanzar(2 * 3600);
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Recién abierta', cuerpo: 'nueva' } });
  s.avanzar(40);
  await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: 'respuesta nueva' } });
  s.avanzar(60);
  // Vuelve después de más de una hora: la publicación nueva y la respuesta nueva se marcan.
  v = await galleta(v.cookie);
  assert.match(v.html, /Recién abierta<\/a><\/strong><\/a>|marca-nuevo">nuevo/);
  assert.ok(v.html.includes('1 nueva'));
  // Recargar enseguida no las borra.
  s.avanzar(600);
  v = await galleta(v.cookie);
  assert.ok(v.html.includes('marca-nuevo">nuevo') && v.html.includes('1 nueva'));
  assert.ok((await (await s.pedir('/h/1', { cookie: v.cookie })).text()).includes('title="Desde tu visita anterior"'));
  // Tras otra hora sin entrar, lo que ya viste deja de ser nuevo.
  s.avanzar(2 * 3600);
  v = await galleta(v.cookie);
  assert.ok(!v.html.includes('marca-nuevo'));
  // Lo propio nunca se marca.
  assert.ok(!(await s.texto('/h/1', ana)).includes('Desde tu visita anterior'));
});

test('mod: los mensajes a revisar y las suspensiones automáticas muestran de dónde salieron', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bob = await s.entrar('bob');
  const mod = await s.entrar('mod');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Series', cuerpo: 'qué están viendo' } });
  s.avanzar(40);
  await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: 'mensaje de antes' } });
  s.filtro.decision = 'reject';
  s.filtro.grave = 'abuso';
  s.avanzar(40);
  await s.pedir('/h/1/responder', { sesion: bob, datos: { cuerpo: '>>1\nalgo grave' } });
  s.filtro.grave = undefined;
  s.filtro.decision = 'queue';
  s.avanzar(40);
  await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: '>>2\ndudoso' } });
  const panel = await s.texto('/mod', mod);
  const ctx = panel.match(/<details class="contexto-mod"[\s\S]*?<\/details>/g);
  assert.equal(ctx.length, 2);
  assert.ok(ctx.every((c) => c.includes('«Series»') && c.includes('href="/h/1"')));
  assert.ok(ctx[0].includes('No.1</a> <strong>(citado)') && ctx[0].includes('mensaje de antes'));
  assert.ok(ctx[1].includes('No.2</a> <strong>(citado)') && ctx[1].includes('qué están viendo'));
});

test('búsqueda sin spoilers, avisos de lo guardado y links en publicaciones largas', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  const cami = await s.entrar('cami');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'F1', cuerpo: 'ganó [spoiler]Colapinto[/spoiler] al final' } });
  // La búsqueda no encuentra ni muestra lo tapado.
  assert.ok(!(await s.texto('/buscar?q=Colapinto')).includes('Colapinto</mark>'));
  assert.ok(!(await s.texto('/buscar?q=final')).match(/Colapinto/));
  // Guardar avisa cuando otra persona comenta; a quien comenta, no.
  await s.pedir('/h/1/guardar', { sesion: cami, datos: {} });
  s.avanzar(40);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'qué carrera' } });
  const avisos = await s.texto('/respuestas', cami);
  assert.ok(avisos.includes('comentó en una publicación que guardaste'));
  s.avanzar(40);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'otra más' } });
  const hilo = await s.texto('/h/1');
  // Con pocas respuestas no hay "Ir al final"; con muchas, sí.
  assert.ok(!hilo.includes('Ir al final'));
  for (let i = 0; i < 8; i++) {
    s.avanzar(40);
    await s.pedir('/h/1/responder', { sesion: i % 2 ? bea : cami, datos: { cuerpo: `mensaje ${i}` } });
  }
  const larga = await s.texto('/h/1');
  assert.ok(larga.includes('href="#fin">↓ Ir al final') && larga.includes('id="fin"><a href="#arriba">'));
});

test('una base con la tabla de avisos vieja se migra sin perder avisos', async () => {
  const fs = await import('node:fs');
  const os = await import('node:os');
  const path = await import('node:path');
  const Database = (await import('better-sqlite3')).default;
  const archivo = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'avisos-')), 'vieja.db');
  const nueva = openDb(archivo);
  nueva.prepare("INSERT INTO users (identidad, created_at) VALUES ('google:1', 1)").run();
  nueva.prepare("INSERT INTO threads (board, subject, created_at, bumped_at) VALUES ('cultura', 'x', 1, 1)").run();
  nueva.prepare("INSERT INTO posts (thread_id, user_id, body, created_at, status) VALUES (1, 1, 'hola', 1, 'published')").run();
  nueva.close();
  // Se vuelve la tabla al esquema de antes (sin 'guardado' en el CHECK), con un aviso adentro.
  const cruda = new Database(archivo);
  cruda.exec(`DROP TABLE notificaciones; CREATE TABLE notificaciones (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    post_id INTEGER NOT NULL REFERENCES posts (id), tipo TEXT NOT NULL CHECK (tipo IN ('comentario', 'respuesta')), created_at INTEGER NOT NULL,
    leida INTEGER NOT NULL DEFAULT 0, UNIQUE (user_id, post_id)); INSERT INTO notificaciones (user_id, post_id, tipo, created_at) VALUES (1, 1, 'comentario', 5);`);
  cruda.close();
  const db = openDb(archivo);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM notificaciones').get().n, 1);
  db.prepare("UPDATE notificaciones SET tipo = 'guardado'").run();
  assert.ok(db.prepare("SELECT sql FROM sqlite_master WHERE name = 'notificaciones_usuario'").get());
  db.close();
});

test('alcance: totales diarios de visitas solo con la clave', async (t) => {
  const s = await montar({ alcanceKey: 'clave-de-prueba' });
  t.after(s.cerrar);
  await fetch(s.base + '/', { headers: { 'user-agent': 'Mozilla/5.0' } });
  s.db.prepare("INSERT INTO visitas_dia (dia, vistas, visitantes, estimado) VALUES ('2026-09-24', 100, 10, 1)").run();
  assert.equal((await s.pedir('/api/alcance.json')).status, 404);
  const mal = await fetch(s.base + '/api/alcance.json', { headers: { authorization: 'Bearer otra' } });
  assert.equal(mal.status, 404);
  const r = await fetch(s.base + '/api/alcance.json', { headers: { authorization: 'Bearer clave-de-prueba' } });
  const { dias } = await r.json();
  assert.deepEqual(dias[0], { dia: '2026-09-24', vistas: 100, visitantes: 10, estimado: true });
  assert.ok(dias[1].vistas >= 1 && dias[1].estimado === false);
  const sin = await montar();
  t.after(sin.cerrar);
  assert.equal((await fetch(sin.base + '/api/alcance.json', { headers: { authorization: 'Bearer ' } })).status, 404);
});

test('Gemini: vincular un certificado con un código, responder y publicar en pasos', async (t) => {
  const { execFileSync } = await import('node:child_process');
  const fs = await import('node:fs');
  const os = await import('node:os');
  const path = await import('node:path');
  const tls = await import('node:tls');
  const { crearCapsula } = await import('../src/gemini.js');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gemini-'));
  const certificado = (nombre) => {
    execFileSync('openssl', ['req', '-x509', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:prime256v1', '-nodes', '-days', '1',
      '-subj', `/CN=${nombre}`, '-keyout', path.join(dir, `${nombre}-k.pem`), '-out', path.join(dir, `${nombre}-c.pem`)], { stdio: 'ignore' });
    return { cert: fs.readFileSync(path.join(dir, `${nombre}-c.pem`)), key: fs.readFileSync(path.join(dir, `${nombre}-k.pem`)) };
  };
  const servidor = certificado('localhost');
  const cliente = certificado('bob');

  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Libros', cuerpo: 'hola' } });

  const capsula = crearCapsula({ documento: s.documento, escritura: s.gemini, baseUrl: 'https://prueba', ...servidor, hosts: ['localhost'] });
  await new Promise((r) => capsula.listen(0, '127.0.0.1', r));
  t.after(() => capsula.close());
  const port = capsula.address().port;
  const pedir = (url, conCert = true) => new Promise((resolve, reject) => {
    const c = tls.connect({ host: '127.0.0.1', port, servername: 'localhost', rejectUnauthorized: false, ...(conCert ? cliente : {}) }, () => c.write(`${url}\r\n`));
    let d = '';
    c.on('data', (x) => (d += x)).on('end', () => resolve(d)).on('error', reject);
  });

  // La lectura sigue igual y ofrece escribir; la versión texto no.
  assert.ok((await pedir('gemini://localhost/h/1')).includes('=> /h/1/responder Responder'));
  assert.ok(!(await s.texto('/h/1.txt')).includes('/responder'));
  // Sin certificado: 60. Con uno sin vincular: un código, nunca se publica.
  assert.ok((await pedir('gemini://localhost/h/1/responder', false)).startsWith('60'));
  const sinVincular = await pedir('gemini://localhost/h/1/responder?hola');
  const codigo = sinVincular.match(/TXT-[A-Z0-9]{6}/)[0];
  assert.ok(sinVincular.startsWith('20') && sinVincular.includes('https://prueba/cuenta#gemini'));
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM posts').get().n, 1);
  assert.equal((await pedir('gemini://localhost/h/1/responder')).match(/TXT-[A-Z0-9]{6}/)[0], codigo, 'mismo código mientras está vigente');

  // Vincular desde la web: un código inventado no sirve; el bueno sí, una sola vez.
  const bob = await s.entrar('bob');
  assert.match((await s.pedir('/cuenta/gemini', { sesion: bob, datos: { codigo: 'TXT-AAAAAA' } })).headers.get('location'), /gemini-invalido/);
  assert.match((await s.pedir('/cuenta/gemini', { sesion: bob, datos: { codigo: codigo.toLowerCase() } })).headers.get('location'), /gemini-ok/);
  assert.match((await s.pedir('/cuenta/gemini', { sesion: ana, datos: { codigo } })).headers.get('location'), /gemini-invalido/);
  assert.ok((await s.texto('/cuenta', bob)).includes('Desvincular'));

  // Responder: 10 pide el texto; con el texto, publica como bob y redirige con 30.
  assert.ok((await pedir('gemini://localhost/h/1/responder')).startsWith('10 '));
  const r = await pedir(`gemini://localhost/h/1/responder?${encodeURIComponent('desde gemini, ¿se ve?')}`);
  assert.equal(r.trim(), 'gemini://localhost/h/1'.replace(/^/, '30 '));
  const post = s.db.prepare('SELECT * FROM posts ORDER BY id DESC LIMIT 1').get();
  assert.equal(post.body, 'desde gemini, ¿se ve?');
  assert.equal(post.user_id, s.db.prepare("SELECT user_id FROM gemini_llaves").get().user_id);
  // Mismos límites que la web: otra respuesta enseguida no pasa.
  assert.ok((await pedir(`gemini://localhost/h/1/responder?otra`)).includes('Esperá'));

  // Publicar en pasos: sección → asunto → mensaje.
  s.avanzar(60);
  assert.ok((await pedir('gemini://localhost/publicar')).includes('=> /publicar/musica Música'));
  assert.ok((await pedir('gemini://localhost/publicar/musica')).startsWith('10 '));
  assert.equal((await pedir('gemini://localhost/publicar/musica?Discos%20nuevos')).trim(), '30 gemini://localhost/publicar/musica/mensaje');
  assert.ok((await pedir('gemini://localhost/publicar/musica/mensaje')).startsWith('10 Discos nuevos'));
  s.filtro.decision = 'reject';
  const rechazo = await pedir('gemini://localhost/publicar/musica/mensaje?malo');
  assert.ok(rechazo.includes('no cumple las normas') && !rechazo.includes('ataca'));
  s.filtro.decision = 'approve';
  const hecho = await pedir('gemini://localhost/publicar/musica/mensaje?Recomienden%20algo');
  assert.match(hecho.trim(), /^30 gemini:\/\/localhost\/h\/\d+$/);
  const hilo = s.db.prepare("SELECT * FROM threads WHERE board = 'musica'").get();
  assert.equal(hilo.subject, 'Discos nuevos');

  // Suspendido: no escribe. Borrar la cuenta borra la llave.
  s.db.prepare("UPDATE users SET banned_until = ? WHERE id = ?").run(9e15, post.user_id);
  s.avanzar(60);
  assert.ok((await pedir('gemini://localhost/h/1/responder?sigo')).includes('No se publicó'));
  s.db.prepare("UPDATE users SET banned_until = NULL WHERE id = ?").run(post.user_id);
  await s.pedir('/cuenta/borrar', { sesion: bob, datos: { confirmar: '1' } });
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM gemini_llaves').get().n, 0);
  assert.ok((await pedir('gemini://localhost/h/1/responder')).includes('TXT-'), 'vuelve a pedir vincular');
});

test('auditoría: texto y Gemini no dejan pasar controles ni sintaxis del usuario; /tema no redirige afuera', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Prueba', cuerpo: '=> gemini://evil.example/ click\n### No.99 · OP falso\nhola' } });
  const { aGemtext } = await import('../src/documentos.js');
  const gem = aGemtext(s.documento('/h/1'), { baseUrl: 'https://prueba' });
  assert.ok(!/^=> gemini:\/\/evil/m.test(gem) && !/^### No\.99/m.test(gem));
  const txt = await s.texto('/h/1.txt');
  assert.ok(/^ {2}### No\.99/m.test(txt));
  // U+009B guardado antes del filtro nuevo no sale en la versión texto.
  s.db.prepare("UPDATE posts SET body = 'a' || char(155) || '31mb' WHERE id = 1").run();
  assert.ok(!(await s.texto('/h/1.txt')).includes(String.fromCharCode(155)));
  for (const malo of ['/\\evil.com', '//evil.com', '/\\/evil.com', 'https://evil.com', '/\tevil']) {
    const r = await s.pedir(`/tema?t=claro&volver=${encodeURIComponent(malo)}`);
    assert.equal(r.headers.get('location'), '/', malo);
  }
  assert.equal((await s.pedir('/tema?t=claro&volver=%2Fh%2F1')).headers.get('location'), '/h/1');
});

test('auditoría: una sola moderación en vuelo por cuenta', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const envios = Array.from({ length: 5 }, (_, i) =>
    s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: `Hilo ${i}`, cuerpo: 'texto' } }));
  await Promise.all(envios);
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM threads').get().n, 1);
});

test('doble toque: el mismo envío repetido termina en un solo mensaje y sin error', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const datos = { asunto: 'Una vez', cuerpo: 'toqué dos veces' };
  const rs = await Promise.all([1, 2, 3].map(() => s.pedir('/b/cultura/hilo', { sesion: ana, datos })));
  assert.deepEqual(rs.map((r) => r.status), [303, 303, 303]);
  assert.deepEqual(new Set(rs.map((r) => r.headers.get('location'))).size, 1);
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM threads').get().n, 1);
  // Un toque que llega cuando el primero ya terminó también va al mensaje existente.
  const tarde = await s.pedir('/b/cultura/hilo', { sesion: ana, datos });
  assert.equal(tarde.headers.get('location'), '/h/1');
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: 'respuesta única' } });
  const otra = await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: 'respuesta única' } });
  assert.equal(otra.headers.get('location'), '/h/1#p2');
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM posts').get().n, 2);
});

test('vista previa: formatea sin publicar y sin pasar por el filtro', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  s.filtro.decision = 'reject';   // si se llamara al filtro, rechazaría
  const r = await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Borrador', cuerpo: '>una cita\nhola', vista: '1' } });
  assert.equal(r.status, 200);
  const html = await r.text();
  assert.ok(html.includes('class="vista-previa"') && html.includes('<span class="verde">&gt;una cita</span>'));
  assert.ok(html.includes('>&gt;una cita\nhola</textarea>'));
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM threads').get().n, 0);
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM rechazos').get().n, 0);
});

test('cambiar el tema nunca manda a una ruta que solo acepta POST', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Libros', cuerpo: 'hola' } });
  const volver = (html, esperado) => {
    const href = html.match(/class="icono a-claro" href="\/tema\?t=claro&amp;volver=([^"]+)"/)[1];
    assert.equal(decodeURIComponent(href), esperado);
  };

  // La página se dibujó desde un POST (vista previa o error): /b/cultura/hilo no acepta GET.
  const previa = await (await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Borrador', cuerpo: 'hola', vista: '1' } })).text();
  volver(previa, '/b/cultura');

  s.filtro.decision = 'reject';
  const error = await (await s.pedir('/hilo', { sesion: ana, datos: { tablon: 'cultura', asunto: 'Rechazado', cuerpo: 'nope' } })).text();
  volver(error, '/');
  const hilo = await (await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: 'nope', vista: '1' } })).text();
  volver(hilo, '/h/1');

  // ?cita= es de una sola vez: si volviera con ella, el servidor escribiría el >>N otra vez en el
  // mensaje y el borrador (que ya lo tiene adentro) no entraría.
  volver(await s.texto('/h/1?cita=1', ana), '/h/1');
  volver(await s.texto('/h/1?vista=lista', ana), '/h/1?vista=lista');
  volver(await s.texto('/b/cultura?publicar=1', ana), '/b/cultura?publicar=1');
});

test('lupa: busca sin tildes, incluye el archivo, no muestra lo oculto y no rompe con sintaxis rara', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Canciones de otoño', cuerpo: 'Busco una canción de Spinetta <b>' } });
  s.avanzar(601);
  s.filtro.decision = 'queue';
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Oculto', cuerpo: 'spinetta en revisión' } });
  s.db.prepare('UPDATE threads SET archived = 1 WHERE id = 1').run();

  const r = await s.texto('/buscar?q=cancion+spinet');
  assert.ok(r.includes('href="/h/1#p1"') && r.includes('<mark>') && r.includes('archivada'));
  assert.ok(!r.includes('en revisión'));
  assert.ok(!(await s.texto('/buscar?q=spinetta')).includes('en revisión'));
  // El <b> que escribió la persona sale escapado dentro del resultado.
  assert.ok(!/class="res-fragmento">[^\n]*<b>/.test(r));
  for (const raro of ['"', 'AND OR NOT', '*', 'a"b(c)', 'NEAR(x y)']) {
    assert.equal((await s.pedir(`/buscar?q=${encodeURIComponent(raro)}`)).status, 200, raro);
  }
  assert.ok((await s.texto('/')).includes('href="/buscar"'));
});

test('prueba en sombra: guarda lo que diría Jev, no decide nada y un error no molesta', async (t) => {
  let llamadas = 0;
  const sombra = async () => {
    llamadas++;
    if (llamadas === 2) throw new Error('TypeSafe 503');
    return { modelo: 'jev-1.13.0', tokens: 500, ms: 90, respuestas: {
      grave: { type: 'choice', choice: 'ninguna', probabilities: { ninguna: 0.97 }, confidence: 0.9 },
      respeto: { type: 'noul', noul: 0.8 }, spam: { type: 'noul', noul: 0.05 },
    } };
  };
  const s = await montar({ sombra });
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Uno', cuerpo: 'hola' } });
  s.avanzar(601);
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Dos', cuerpo: 'chau' } });
  await new Promise((r) => setTimeout(r, 30));
  // Claude aprobó los dos: se publicaron igual, aunque Jev habría rechazado uno y falló en el otro.
  assert.equal(s.db.prepare("SELECT COUNT(*) AS n FROM threads WHERE visible = 1").get().n, 2);
  const filas = s.db.prepare('SELECT jev_decision, jev_rule, error FROM sombra_jev ORDER BY id').all();
  assert.deepEqual(filas[0], { jev_decision: 'reject', jev_rule: 'respeto', error: null });
  assert.match(filas[1].error, /503/);
  const mod = await s.entrar('mod');
  const panel = await s.texto('/mod/sombra', mod);
  assert.ok(panel.includes('Mensajes que vio Jev: <strong>2</strong>') && panel.includes('1 con error'));
  assert.equal((await s.pedir('/mod/sombra', { sesion: ana })).status, 404);
  assert.ok((await s.texto('/privacidad')).includes('TypeSafe'));
});

test('prueba en sombra: si no se puede guardar la comparación, queda en el log y se publica igual', async (t) => {
  const errores = t.mock.method(console, 'error', () => {});
  // Excepción síncrona, antes de devolver una promesa: antes se escapaba del .catch.
  const s = await montar({ sombra: () => { throw new Error('TypeSafe 503'); } });
  t.after(s.cerrar);
  s.db.exec(`CREATE TRIGGER fallo_sombra BEFORE INSERT ON sombra_jev BEGIN SELECT RAISE(FAIL, 'disco lleno'); END`);
  const ana = await s.entrar('ana');
  const r = await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Uno', cuerpo: 'hola' } });
  await new Promise((r) => setTimeout(r, 30));
  assert.equal(r.status, 303);
  assert.equal(s.db.prepare('SELECT visible FROM threads').get().visible, 1);
  assert.equal(errores.mock.callCount(), 1);
  assert.match(errores.mock.calls[0].arguments[1].message, /disco lleno/);
});

test('estadísticas: cuenta visitas sin bots ni estáticos, activos, y solo la ven los mods', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const nav = { 'user-agent': 'Mozilla/5.0 (iPhone)' };
  await fetch(s.base + '/', { headers: nav });
  await fetch(s.base + '/normas', { headers: nav });
  await fetch(s.base + '/', { headers: { 'user-agent': 'Googlebot/2.1' } });
  await fetch(s.base + '/static/style.css', { headers: nav });
  await fetch(s.base + '/index.txt', { headers: nav });
  // Cambiar el tema o la vista es un paso de ida y vuelta, no una página vista.
  await fetch(s.base + '/tema?t=claro&volver=%2F', { headers: nav, redirect: 'manual' });
  await fetch(s.base + '/vista?v=lista&volver=%2F', { headers: nav, redirect: 'manual' });
  const v = s.db.prepare('SELECT vistas, visitantes FROM visitas_dia').get();
  assert.deepEqual(v, { vistas: 2, visitantes: 1 });
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Hola', cuerpo: 'algo' } });
  // Costo: un millón de tokens de entrada de Claude (US$2) + un millón de Jev (US$0,042).
  s.db.prepare("UPDATE posts SET mod_model = 'claude-sonnet-5', mod_input_tokens = 1000000, mod_output_tokens = 0").run();
  s.db.prepare("INSERT INTO sombra_jev (created_at, tokens) VALUES ((SELECT MAX(created_at) FROM posts), 1000000)").run();
  const mod = await s.entrar('mod');
  const r = await fetch(s.base + '/mod/estadisticas', { headers: { cookie: mod.cookie, ...nav } });
  const html = await r.text();
  assert.ok(html.includes('Publicaciones hoy') && html.includes('<svg viewBox'));
  assert.match(html, /US\$2\.04<\/span><span class="tile-k">Costo de moderación hoy/);
  // Eje vertical con valores y, junto al título, el acumulado (o el promedio en lo que no se suma).
  assert.match(html, /class="eje-y">0<\/text>/);
  assert.match(html, /class="eje-y">US\$3\.00<\/text>/);
  assert.ok(html.includes('acumulado 2') && html.includes('acumulado US$2.04') && html.includes('promedio 0 por día'));
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM actividad_dia').get().n >= 1, true);
  assert.equal((await s.pedir('/mod/estadisticas', { sesion: ana })).status, 404);
  // No queda ninguna IP guardada: solo hashes del día.
  assert.ok(!JSON.stringify(s.db.prepare('SELECT * FROM visitantes_dia').all()).includes('127.0.0.1'));
});

test('guardados: guardar, verlos desde la portada, sacarlos y borrarlos con la cuenta', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Para-leer-despues', cuerpo: 'texto' } });

  assert.ok((await s.texto('/', bea)).includes('href="/guardados"'), 'la portada lleva a guardados');
  assert.ok(!(await s.texto('/')).includes('href="/guardados"'), 'sin sesión no aparece');
  assert.equal((await s.pedir('/guardados')).status, 303);
  assert.ok(!(await s.texto('/guardados', bea)).includes('Para-leer-despues'));

  // Sin CSRF no se guarda.
  assert.equal((await s.pedir('/h/1/guardar', { cookie: bea.cookie, datos: {} })).status, 403);

  const r = await s.pedir('/h/1/guardar', { sesion: bea, datos: {} });
  assert.equal(r.status, 303);
  assert.equal(r.headers.get('location'), '/h/1');
  assert.ok((await s.texto('/guardados', bea)).includes('Para-leer-despues'));
  const hilo = await s.texto('/h/1', bea);
  assert.ok(hilo.includes('Sacar de guardados'));
  // Ningún <form> adentro de un <p>: el navegador cerraría el párrafo y el botón quedaría suelto.
  assert.ok(!/<p(?:\s[^>]*)?>(?:(?!<\/p>)[\s\S])*<form/.test(hilo));
  assert.ok(!(await s.texto('/guardados', ana)).includes('Para-leer-despues'), 'solo los ve quien guardó');

  await s.pedir('/h/1/guardar', { sesion: bea, datos: { quitar: '1' } });
  assert.ok(!(await s.texto('/guardados', bea)).includes('Para-leer-despues'));
  assert.equal((await s.pedir('/h/99/guardar', { sesion: bea, datos: {} })).status, 404);

  await s.pedir('/h/1/guardar', { sesion: bea, datos: {} });
  await s.pedir('/cuenta/borrar', { sesion: bea, datos: { confirmar: '1' } });
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM guardados').get().n, 0);
});

test('la sección Música existe, se puede publicar y está en la barra', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  assert.equal((await s.pedir('/b/musica')).status, 200);
  const r = await s.pedir('/b/musica/hilo', { sesion: ana, datos: { asunto: 'Discos del año', cuerpo: 'qué están escuchando' } });
  assert.equal(r.status, 303);
  assert.ok((await s.texto('/')).includes('href="/b/musica"'));
});

test('borrar un mensaje propio: queda "Eliminado por su autor", sale de la búsqueda y baja el contador', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'respuesta de Zanahoria' } });
  assert.equal(s.db.prepare('SELECT reply_count FROM threads WHERE id = 1').get().reply_count, 1);

  // En tus mensajes aparece "Borrar" en lugar de "Reportar".
  const hilo = await s.texto('/h/1', bea);
  assert.ok(hilo.includes('<a class="reportar" href="/p/2/borrar" rel="nofollow">Borrar</a>'));
  assert.ok(!hilo.includes('href="/p/2/reportar"') && !hilo.includes('href="/p/1/borrar"'));
  const pagina = await s.texto('/p/2/borrar', bea);
  assert.ok(pagina.includes('action="/p/2/borrar"') && pagina.includes('Zanahoria') && pagina.includes('noindex'));

  // Solo el autor, con sesión y con CSRF.
  assert.equal((await s.pedir('/p/2/borrar')).headers.get('location'), '/entrar');
  assert.equal((await s.pedir('/p/2/borrar', { sesion: ana })).status, 404, 'ajeno');
  assert.equal((await s.pedir('/p/2/borrar', { sesion: ana, datos: {} })).status, 404, 'ajeno');
  assert.equal((await s.pedir('/p/2/borrar', { cookie: bea.cookie, datos: {} })).status, 403, 'sin CSRF');
  assert.ok((await s.texto('/buscar?q=Zanahoria')).includes('Zanahoria</mark>'));

  const r = await s.pedir('/p/2/borrar', { sesion: bea, datos: {} });
  assert.equal(r.headers.get('location'), '/h/1?aviso=mensaje-borrado#p2');
  const despues = await s.texto('/h/1');
  assert.ok(!despues.includes('Zanahoria') && despues.includes('Eliminado por su autor'));
  assert.equal(s.db.prepare('SELECT reply_count FROM threads WHERE id = 1').get().reply_count, 0);
  assert.ok(!(await s.texto('/buscar?q=Zanahoria')).includes('Zanahoria</mark>'));
  assert.equal((await s.pedir('/p/2/borrar', { sesion: bea, datos: {} })).status, 404, 'ya borrado');

  // En /mod no cuenta como eliminado por moderación.
  s.filtro.decision = 'queue';
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'otra' } });
  const mod = await s.entrar('mod');
  assert.ok((await s.texto('/mod', mod)).includes('0 eliminados antes'));
});

test('borrar el mensaje que abre la publicación: con respuestas de otros queda "(eliminada)"; sin ellas se oculta', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Asunto Berenjena', cuerpo: 'texto-uno' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'respuesta-de-bea' } });
  s.avanzar(601);
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Asunto-dos', cuerpo: 'texto-dos' } });
  s.avanzar(31);
  await s.pedir('/h/2/responder', { sesion: ana, datos: { cuerpo: 'me-respondo' } });

  assert.ok((await s.texto('/p/1/borrar', ana)).includes('(eliminada)'), 'la confirmación lo avisa');
  await s.pedir('/p/1/borrar', { sesion: ana, datos: {} });
  const uno = await s.texto('/h/1');
  assert.ok(uno.includes('(eliminada)') && !uno.includes('Berenjena') && !uno.includes('texto-uno'));
  assert.ok(uno.includes('respuesta-de-bea'));
  assert.ok((await s.texto('/buscar?q=texto')).includes('texto</mark>-dos'), 'la otra sigue en la búsqueda');
  assert.deepEqual(s.db.prepare('SELECT asunto, cuerpo FROM busqueda WHERE rowid = 1').get(), { asunto: '', cuerpo: '' });

  await s.pedir('/p/3/borrar', { sesion: ana, datos: {} });
  assert.equal((await s.pedir('/h/2')).status, 404, 'solo tenía respuestas propias');
  assert.ok(!(await s.texto('/b/cultura')).includes('Asunto-dos'));
});

test('lo que está en revisión o con reportes abiertos no se borra hasta que lo resuelva un mod', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'reportada' } });
  s.filtro.decision = 'queue';
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: bea, datos: { cuerpo: 'en-revision' } });

  // En revisión: sin botón, y la página explica por qué.
  assert.ok(!(await s.texto('/h/1', bea)).includes('href="/p/3/borrar"'));
  assert.ok((await s.texto('/p/3/borrar', bea)).includes('lo resuelva un moderador'));
  assert.equal((await s.pedir('/p/3/borrar', { sesion: bea, datos: {} })).headers.get('location'), '/p/3/borrar');
  assert.equal(s.db.prepare('SELECT status FROM posts WHERE id = 3').get().status, 'queued');

  // Con un reporte abierto tampoco.
  await s.pedir('/p/2/reportar', { sesion: ana, datos: { motivo: 'respeto' } });
  const pagina = await s.texto('/p/2/borrar', bea);
  assert.ok(pagina.includes('lo resuelva un moderador') && !pagina.includes('action="/p/2/borrar"'));
  await s.pedir('/p/2/borrar', { sesion: bea, datos: {} });
  assert.ok((await s.texto('/h/1')).includes('reportada'));

  // Cuando el mod descarta el reporte, se puede.
  const mod = await s.entrar('mod');
  await s.pedir('/mod/p/2/descartar', { sesion: mod, datos: {} });
  await s.pedir('/p/2/borrar', { sesion: bea, datos: {} });
  assert.ok(!(await s.texto('/h/1')).includes('reportada'));
});

test('largo: un mensaje de 8.000 caracteres entra aunque sean de 3 bytes, y uno más no', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  // "語" ocupa 9 bytes en el formulario (%E8%AA%9E): 8.000 pasan los 64 KB del tope viejo.
  const r = await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Largo', cuerpo: '語'.repeat(8000) } });
  assert.equal(r.status, 303);
  assert.equal(s.db.prepare('SELECT length(body) AS n FROM posts').get().n, 8000);
  s.avanzar(31);
  const largo = await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: 'a'.repeat(8001) } });
  assert.ok((await largo.text()).includes('hasta 8000 caracteres'));
  assert.equal(s.db.prepare('SELECT COUNT(*) AS n FROM posts').get().n, 1);
});

test('publicar y responder: el navegador no rellena el formulario con lo ya enviado al volver atrás', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  assert.ok((await s.texto('/b/cultura', ana)).includes('<form class="form-post" method="post" autocomplete="off" action="/b/cultura/hilo">'));
  assert.ok((await s.texto('/h/1', ana)).includes('<form class="form-post" method="post" autocomplete="off" action="/h/1/responder" id="responder">'));
});

test('donde participaste: está en Respuestas y ya no en Mi cuenta', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Asunto Remolacha', cuerpo: 'arranque' } });
  const respuestas = await s.texto('/respuestas', ana);
  assert.ok(respuestas.includes('<h2>Donde participaste</h2>') && respuestas.includes('Asunto Remolacha'));
  const cuenta = await s.texto('/cuenta', ana);
  assert.ok(!cuenta.includes('Donde participaste') && !cuenta.includes('Asunto Remolacha'));
  assert.ok(cuenta.includes('<h2>Preferencias</h2>') && cuenta.includes('Borrar la cuenta'));
});

test('aviso de moderación: los mods ven cuántos mensajes esperan en /mod, y nadie más', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const ana = await s.entrar('ana');
  const bea = await s.entrar('bea');
  const mod = await s.entrar('mod');
  assert.ok(!(await s.texto('/', mod)).includes('mod-pendientes'), 'sin nada pendiente no aparece');
  await s.pedir('/b/cultura/hilo', { sesion: ana, datos: { asunto: 'Tema', cuerpo: 'arranque' } });
  s.filtro.decision = 'queue';
  s.avanzar(31);
  await s.pedir('/h/1/responder', { sesion: ana, datos: { cuerpo: 'en revisión' } });
  // Un reporte abierto sobre el mensaje publicado suma otro.
  await s.pedir('/p/1/reportar', { sesion: bea, datos: { motivo: 'respeto' } });
  const pagina = await s.texto('/', mod);
  assert.ok(pagina.includes('<a class="icono mod-pendientes" href="/mod"') && pagina.includes('<span class="badge">2</span></a>'));
  assert.ok(pagina.includes('Moderación (2)'));
  assert.ok(!(await s.texto('/', ana)).includes('mod-pendientes'), 'un usuario común no lo ve');
  await s.pedir('/mod/p/1/descartar', { sesion: mod, datos: {} });
  assert.ok((await s.texto('/', mod)).includes('Moderación (1)'));
});

test('Leé 421: al final de las secciones y del menú del celular, con la última nota en el title', async (t) => {
  const s = await montar();
  t.after(s.cerrar);
  const pagina = await s.texto('/');
  const link = 'href="https://www.421.news/es/?utm_source=txt&amp;utm_medium=secciones"';
  assert.equal(pagina.split(`<a class="leer-421" ${link}>Leé 421 ↗</a>`).length - 1, 2, 'barra de secciones y menú del celular, sin title si no hay nota');
});

test('Leé 421: la última nota se pide a Ghost y va escapada en el title; si Ghost falla, queda la anterior', async (t) => {
  const { crearUltimaNota } = await import('../src/nota421.js');
  let respuesta = { ok: true, json: async () => ({ posts: [{ title: 'Nota <con> "comillas"' }] }) };
  const pedidos = [];
  const errores = t.mock.method(console, 'error', () => {});
  const titulo = crearUltimaNota({ pedir: async (url) => (pedidos.push(url), respuesta), cada: 60_000 });
  await new Promise((r) => setImmediate(r));
  assert.equal(titulo(), 'Nota <con> "comillas"');
  assert.match(pedidos[0], /421bn\.ghost\.io\/ghost\/api\/content\/posts\/\?key=\w+&limit=1&fields=title&filter=tag:hash-es/);
  assert.equal(errores.mock.callCount(), 0);

  const s = await montar({ ultimaNota421: titulo });
  t.after(s.cerrar);
  assert.ok((await s.texto('/')).includes('title="Última nota: Nota &lt;con&gt; &quot;comillas&quot;">Leé 421 ↗</a>'));
});
